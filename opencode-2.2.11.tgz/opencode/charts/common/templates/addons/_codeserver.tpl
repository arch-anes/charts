{{/*
Template to render code-server addon
It will include / inject the required templates based on the given values.
*/}}
{{- define "tc.v1.common.addon.codeserver" -}}
  {{- $codeSrv := $.Values.addons.codeserver -}}

  {{- if $codeSrv.enabled -}}
    {{- $targetSelector := list "main" -}}
    {{- if $codeSrv.targetSelector -}}
      {{- $targetSelector = $codeSrv.targetSelector -}}
    {{- end -}}

    {{- if gt ($targetSelector|len) 1 -}}
      {{- fail "Codeserver Addon - Can only be attached to a single workload at a time" -}}
    {{- end -}}

    {{/* Append the code-server container to the workloads */}}
    {{- range $targetSelector -}}
      {{- $workload := get $.Values.workload . -}}
      {{- $_ := set $workload.podSpec.containers "codeserver" $codeSrv.container -}}
    {{- end -}}

    {{/* Add the code-server service */}}
    {{- if $codeSrv.service.enabled -}}
      {{/* Add the code-server service */}}
      {{/* Addons of a dependency never set primaries, the objects of a dependency are only primary when explicitly set ([$.dependency] is only set for dependencies) */}}
      {{- $hasPrimaryService := kindIs "string" $.dependency -}}
      {{- if not $hasPrimaryService -}}
        {{- $result := (include "tc.v1.common.lib.service.hasPrimary" $) | fromJson -}}
        {{- if and $result.hasEnabled $result.hasPrimary -}}
          {{- $hasPrimaryService = true -}}
        {{- end -}}
      {{- end -}}

      {{- $svcValues := $codeSrv.service -}}
      {{- $_ := set $svcValues "targetSelector" ($targetSelector|first) -}}
      {{- if not $hasPrimaryService -}}
        {{- $_ := set $svcValues "primary" true -}}
      {{- end -}}

      {{- if not $.Values.service -}}
        {{- $_ := set $.Values "service" dict -}}
      {{- end -}}

      {{- $_ := set $.Values.service "codeserver" $svcValues -}}
    {{- end -}}

    {{/* Add the code-server ingress */}}
    {{- if $codeSrv.ingress.enabled -}}
      {{- $ingressValues := $codeSrv.ingress -}}
      {{- if not $ingressValues.targetSelector -}}
        {{/* Assumes that both service and port are named codeserver */}}
        {{- $_ := set $ingressValues "targetSelector" (dict "codeserver" "codeserver") -}}
      {{- end -}}

      {{- $hasPrimaryIngress := kindIs "string" $.dependency -}}
      {{- if not $hasPrimaryIngress -}}
        {{- $result := (include "tc.v1.common.lib.ingress.hasPrimary" $) | fromJson -}}
        {{- if and $result.hasEnabled $result.hasPrimary -}}
          {{- $hasPrimaryIngress = true -}}
        {{- end -}}
      {{- end -}}

      {{- if not $hasPrimaryIngress -}}
        {{- $_ := set $ingressValues "primary" true -}}
      {{- end -}}

      {{- if not $.Values.ingress -}}
        {{- $_ := set $.Values "ingress" dict -}}
      {{- end -}}

      {{/* Let spawner handle the rest */}}
      {{- $_ := set $.Values.ingress "codeserver" $ingressValues -}}
    {{- end -}}

    {{/* Add the code-server route */}}
    {{- if $codeSrv.route.enabled -}}
      {{- $routeValues := $codeSrv.route -}}
      {{- if not $routeValues.targetSelector -}}
        {{/* Assumes that both service and port are named codeserver */}}
        {{- $_ := set $routeValues "targetSelector" (dict "codeserver" "codeserver") -}}
      {{- end -}}

      {{- $hasPrimaryRoute := kindIs "string" $.dependency -}}
      {{- range $name, $route := ($.Values.route | default dict) -}}
        {{- if and (kindIs "map" $route) $route.primary (eq (include "tc.v1.common.lib.gateway.enabled" (dict "rootCtx" $ "objectData" $route "name" $name "key" "route" "caller" "Route")) "true") -}}
          {{- $hasPrimaryRoute = true -}}
        {{- end -}}
      {{- end -}}

      {{- if not $hasPrimaryRoute -}}
        {{- $_ := set $routeValues "primary" true -}}
      {{- end -}}

      {{- if not $.Values.route -}}
        {{- $_ := set $.Values "route" dict -}}
      {{- end -}}

      {{/* Let spawner handle the rest */}}
      {{- $_ := set $.Values.route "codeserver" $routeValues -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
