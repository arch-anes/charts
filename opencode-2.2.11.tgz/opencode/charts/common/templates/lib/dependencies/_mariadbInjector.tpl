{{/*
Extra connection strings of the mariadb dependency, for apps that need another scheme or format than [url].
Returns a json map of key -> value. The same keys are added to [depconfig.creds] and to the secret.
Keep the keys in sync with docs/dependencies/index.md.
user, pass: raw values (encoded here where the format needs it), host, port, db
*/}}
{{- define "tc.v1.common.lib.dependencies.mariadb.variants" -}}
  {{- $urlUser := .user | urlquery | replace "+" "%20" -}}
  {{- $urlPass := .pass | urlquery | replace "+" "%20" -}}
  {{- $portHost := printf "%v:%v" .host .port -}}
  {{- $path := printf "%v@%v/%v" (printf "%v:%v" $urlUser $urlPass) $portHost .db -}}
  {{- $variants := dict
        "urlmariadb" (printf "mariadb://%v" $path)
        "urlmysql2" (printf "mysql2://%v" $path)
        "urlpymysql" (printf "mysql+pymysql://%v" $path)
        "authporthost" (printf "%v:%v@%v" $urlUser $urlPass $portHost)
        "jdbcauth" (printf "jdbc:mariadb://%v/%v?user=%v&password=%v" $portHost .db $urlUser $urlPass)
        "dotnet" (printf "Server=%v;Port=%v;Database=%v;User ID=%v;Password=%v" .host .port .db .user .pass) -}}
  {{- $variants | toJson -}}
{{- end -}}

{{/*
This template generates the mariadb credentials and the secret holding them
*/}}
{{- define "tc.v1.common.dependencies.mariadb.secret" -}}

  {{- $dep := get (.Values.dependencies | default dict) "mariadb" -}}

  {{- if kindIs "map" $dep -}}
    {{- $enabled := (include "tc.v1.common.lib.util.enabled" (dict
                    "rootCtx" $ "objectData" $dep
                    "name" "mariadb" "caller" "Dependencies"
                    "key" "dependencies")) -}}

    {{- if eq $enabled "true" -}}
      {{- if not (kindIs "map" $dep.depconfig) -}}
        {{- $_ := set $dep "depconfig" dict -}}
      {{- end -}}
      {{- if not (kindIs "map" $dep.depconfig.creds) -}}
        {{- $_ := set $dep.depconfig "creds" dict -}}
      {{- end -}}

      {{/* The passwords default to placeholders in values, they must not be empty */}}
      {{- include "tc.v1.common.lib.dependencies.requirePassword" (dict "rootCtx" $ "dep" $dep "depName" "mariadb" "key" "password") -}}
      {{- include "tc.v1.common.lib.dependencies.requirePassword" (dict "rootCtx" $ "dep" $dep "depName" "mariadb" "key" "rootPassword") -}}
      {{- $dbPass := $dep.depconfig.password -}}
      {{- $rootPass := $dep.depconfig.rootPassword -}}

      {{/* The image skips shorter passwords, which would leave the database without any */}}
      {{- range $key, $pass := (dict "password" $dbPass "rootPassword" $rootPass) -}}
        {{- if lt (len (toString $pass)) 4 -}}
          {{- fail (printf "Dependencies - Expected [dependencies.mariadb.depconfig.%s] to have at least 4 characters" $key) -}}
        {{- end -}}
      {{- end -}}

      {{/* The host is the primary service of the dependency */}}
      {{- $service := (include "tc.v1.common.lib.dependencies.primaryService" (dict "rootCtx" $ "depName" "mariadb")) -}}
      {{- if not $service -}}
        {{- fail "Dependencies - Expected dependency [mariadb] to have an enabled primary service" -}}
      {{- end -}}
      {{- $service = $service | fromJson -}}
      {{- if not $service.port -}}
        {{- fail "Dependencies - Expected the primary service of dependency [mariadb] to have a primary port" -}}
      {{- end -}}

      {{- $dbHost := $service.name -}}
      {{- $dbPort := $service.port -}}
      {{- $dbUser := $dep.depconfig.mariadbUsername -}}
      {{- $dbName := $dep.depconfig.mariadbDatabase -}}
      {{- $portHost := printf "%v:%v" $dbHost $dbPort -}}
      {{/* Credentials in urls have to be encoded, a literal "+" is already "%2B", so every remaining "+" was a space */}}
      {{- $urlUser := $dbUser | urlquery | replace "+" "%20" -}}
      {{- $urlPass := $dbPass | urlquery | replace "+" "%20" -}}
      {{- $complete := printf "mysql://%v:%v@%v/%v" $urlUser $urlPass $portHost $dbName -}}
      {{- $urlnossl := printf "%v?sslmode=disable" $complete -}}
      {{- $jdbc := printf "jdbc:mariadb://%v/%v" $portHost $dbName -}}
      {{- $jdbcMySQL := printf "jdbc:mysql://%v/%v" $portHost $dbName -}}

      {{/* Append values to depconfig.creds, so apps using the dependency can use them */}}
      {{- $_ := set $dep.depconfig.creds "mariadbPassword" ($dbPass | quote) -}}
      {{- $_ := set $dep.depconfig.creds "mariadbRootPassword" ($rootPass | quote) -}}
      {{- $_ := set $dep.depconfig.creds "plain" ($dbHost | quote) -}}
      {{- $_ := set $dep.depconfig.creds "plainhost" ($dbHost | quote) -}}
      {{- $_ := set $dep.depconfig.creds "plainport" ($dbPort | quote) -}}
      {{- $_ := set $dep.depconfig.creds "plainporthost" ($portHost | quote) -}}
      {{- $_ := set $dep.depconfig.creds "complete" ($complete | quote) -}}
      {{- $_ := set $dep.depconfig.creds "urlnossl" ($urlnossl | quote) -}}
      {{- $_ := set $dep.depconfig.creds "jdbc" ($jdbc | quote) -}}
      {{- $_ := set $dep.depconfig.creds "jdbcmysql" ($jdbcMySQL | quote) -}}
      {{- $_ := set $dep.depconfig.creds "jdbcmariadb" ($jdbc | quote) -}}
      {{/* More formats of the connection, for apps that need another scheme than [url] */}}
      {{- $variants := include "tc.v1.common.lib.dependencies.mariadb.variants" (dict "user" $dbUser "pass" $dbPass "host" $dbHost "port" $dbPort "db" $dbName) | fromJson -}}
      {{- range $key, $value := $variants -}}
        {{- $_ := set $dep.depconfig.creds $key ($value | quote) -}}
      {{- end -}}

{{/* Create the secret (Comment also plays a role on correct formatting) */}}
enabled: true
expandObjectName: false
data:
  mariadb-password: {{ $dbPass | quote }}
  mariadb-root-password: {{ $rootPass | quote }}
  url: {{ $complete | quote }}
  urlnossl: {{ $urlnossl | quote }}
  plainporthost: {{ $portHost | quote }}
  plainhost: {{ $dbHost | quote }}
  jdbc: {{ $jdbc | quote }}
  jdbc-mysql: {{ $jdbcMySQL | quote }}
  jdbc-mariadb: {{ $jdbc | quote }}
      {{- range $key, $value := $variants }}
  {{ $key }}: {{ $value | quote }}
      {{- end }}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- define "tc.v1.common.dependencies.mariadb.injector" -}}
  {{- $secret := include "tc.v1.common.dependencies.mariadb.secret" . | fromYaml -}}
  {{- if $secret -}}
    {{- $_ := set .Values.secret (printf "%s-%s" .Release.Name "mariadbcreds") $secret -}}
  {{- end -}}
{{- end -}}
