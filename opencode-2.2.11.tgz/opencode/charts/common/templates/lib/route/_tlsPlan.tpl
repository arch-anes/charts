{{/* Plans the listeners and certificates of all routes of this chart.
Listeners with the same hostname and port conflict on a gateway, and the oldest one wins. So routes
that share a hostname, for example with different paths, must share one listener and one certificate.
*/}}
{{- define "tc.v1.common.lib.route.tlsPlan" -}}
  {{- $rootCtx := .rootCtx -}}
  {{- $chartName := include "tc.v1.common.lib.chart.names.fullname" $rootCtx -}}

  {{- $listenerSets := dict -}}
  {{- $certificates := dict -}}
  {{- $routeParents := dict -}}
  {{- $seenHosts := dict -}}

  {{- range $name, $route := ($rootCtx.Values.route | default dict) -}}
    {{- if ne (include "tc.v1.common.lib.gateway.enabled" (dict "rootCtx" $rootCtx "objectData" $route "name" $name "key" "route" "caller" "Route")) "true" -}}
      {{- continue -}}
    {{- end -}}

    {{- $fullName := include "tc.v1.common.lib.route.getFullName" (dict "rootCtx" $rootCtx "objectData" $route "name" $name) -}}
    {{- $listeners := (include "tc.v1.common.lib.route.listeners" (dict "rootCtx" $rootCtx "objectData" $route "fullName" $chartName) | fromYaml).listeners -}}
    {{- if not $listeners -}}{{- continue -}}{{- end -}}

    {{- $gatewayRef := include "tc.v1.common.lib.route.gatewayRef" (dict "rootCtx" $rootCtx "objectData" $route "fullName" $fullName) | fromYaml -}}
    {{- $port := ($route.listenerPort | default $rootCtx.Values.global.fallbackDefaults.routeListenerPort) | int -}}
    {{- $namespace := include "tc.v1.common.lib.metadata.namespace" (dict "rootCtx" $rootCtx "objectData" $route "caller" "Route") -}}
    {{- $parents := list -}}

    {{- range $listener := $listeners -}}
      {{/* One issuer annotation per ListenerSet, so each issuer gets its own */}}
      {{- $setName := printf "%s-%s-%d" $chartName $gatewayRef.name $port -}}
      {{- with $listener.issuer -}}
        {{- $setName = printf "%s-%s" $setName . -}}
      {{- end -}}

      {{- $hostKey := printf "%s/%s/%d/%s" $gatewayRef.namespace $gatewayRef.name $port $listener.host -}}
      {{- $seen := get $seenHosts $hostKey -}}
      {{- if $seen -}}
        {{- if or (ne $seen.secretName $listener.secretName) (ne ($seen.issuer | default "") ($listener.issuer | default "")) (ne $seen.namespace $namespace) -}}
          {{- fail (printf "Route - Routes [%s] and [%s] use hostname [%s] on the same gateway and port, so they share a listener, but with different TLS settings. Set the same TLS on both" $seen.route $name $listener.host) -}}
        {{- end -}}
      {{- else -}}
        {{- $_ := set $seenHosts $hostKey (dict "route" $name "secretName" $listener.secretName "issuer" ($listener.issuer | default "") "namespace" $namespace) -}}

        {{- $setKey := printf "%s/%s" $namespace $setName -}}
        {{- $set := get $listenerSets $setKey -}}
        {{- if not $set -}}
          {{- $set = dict "name" $setName "namespace" $namespace "gatewayRef" $gatewayRef "port" $port "issuer" ($listener.issuer | default "") "labels" dict "listeners" list -}}
        {{- end -}}
        {{- if ne $set.gatewayRef.namespace $gatewayRef.namespace -}}
          {{- fail (printf "Route - Route [%s] selects gateway [%s] in namespace [%s], but another route selects a gateway with that name in namespace [%s]. Use one of them per chart" $name $gatewayRef.name $gatewayRef.namespace $set.gatewayRef.namespace) -}}
        {{- end -}}
        {{- $_ := set $set "listeners" (mustAppend $set.listeners (dict "host" $listener.host "secretName" $listener.secretName)) -}}
        {{- $_ := set $set "labels" (mustMerge $set.labels ($route.labels | default dict)) -}}
        {{- $_ := set $listenerSets $setKey $set -}}
      {{- end -}}

      {{- if not (mustHas $setName $parents) -}}
        {{- $parents = mustAppend $parents $setName -}}
      {{- end -}}
    {{- end -}}
    {{- $_ := set $routeParents $name $parents -}}

    {{/* Routes with the same certificate only create it once */}}
    {{- if not (include "tc.v1.common.lib.route.hasCertManager" (dict "rootCtx" $rootCtx "objectData" $route)) -}}
      {{- range $t := $route.tls -}}
        {{- if $t.certificateIssuer -}}
          {{- $hosts := list -}}
          {{- range $h := $t.hosts -}}
            {{- $hosts = mustAppend $hosts (tpl $h $rootCtx) -}}
          {{- end -}}
          {{- $certName := include "tc.v1.common.lib.route.secretName" (dict "chartName" $chartName "host" (first $hosts)) -}}
          {{/* The certificate lives in the namespace of the route, so the same name in another namespace is another certificate */}}
          {{- $certKey := printf "%s/%s" $namespace $certName -}}
          {{- $existing := get $certificates $certKey -}}
          {{- if and $existing (or (ne $existing.certificateIssuer $t.certificateIssuer) (not (deepEqual $existing.hosts $hosts))) -}}
            {{- fail (printf "Route - Certificate [%s] is defined with different hosts or issuers. Routes that share a hostname must set the same [tls]" $certName) -}}
          {{- end -}}
          {{- $_ := set $certificates $certKey (dict "name" $certName "namespace" $namespace "shortName" $name "hosts" $hosts "certificateIssuer" $t.certificateIssuer) -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}

  {{/* The listener sets of this chart can not take a name or a listener that a route needs, the oldest listener would win */}}
  {{- range $name, $set := ($rootCtx.Values.listenerSet | default dict) -}}
    {{- if ne (include "tc.v1.common.lib.gateway.enabled" (dict "rootCtx" $rootCtx "objectData" $set "name" $name "key" "listenerSet" "caller" "ListenerSet")) "true" -}}
      {{- continue -}}
    {{- end -}}

    {{- $namespace := include "tc.v1.common.lib.metadata.namespace" (dict "rootCtx" $rootCtx "objectData" $set "caller" "ListenerSet") -}}
    {{- $setName := include "tc.v1.common.lib.listenerSet.getFullName" (dict "rootCtx" $rootCtx "objectData" $set "name" $name) -}}
    {{- if hasKey $listenerSets (printf "%s/%s" $namespace $setName) -}}
      {{- fail (printf "Route - ListenerSet [%s] created for the TLS of a route has the same name as [listenerSet.%s]. Rename one of them" $setName $name) -}}
    {{- end -}}

    {{- $parentRef := $set.parentRef | default dict -}}
    {{- $gatewayName := "" -}}
    {{- $gatewayNamespace := $namespace -}}
    {{- if $set.targetSelector -}}
      {{- $target := get ($rootCtx.Values.gateway | default dict) $set.targetSelector -}}
      {{- if not (kindIs "map" $target) -}}{{- continue -}}{{- end -}}
      {{- $gatewayName = include "tc.v1.common.lib.util.gateway.getFullName" (dict "rootCtx" $rootCtx "name" $set.targetSelector) -}}
      {{- $gatewayNamespace = include "tc.v1.common.lib.metadata.namespace" (dict "rootCtx" $rootCtx "objectData" $target "caller" "ListenerSet") -}}
    {{- else if $parentRef.name -}}
      {{- $gatewayName = tpl (toString $parentRef.name) $rootCtx -}}
      {{- with $parentRef.namespace -}}
        {{- $gatewayNamespace = tpl (toString .) $rootCtx -}}
      {{- end -}}
    {{- end -}}

    {{- range $listener := $set.listeners -}}
      {{- $host := "" -}}
      {{- with $listener.hostname -}}
        {{- $host = tpl . $rootCtx -}}
      {{- end -}}
      {{- $seen := get $seenHosts (printf "%s/%s/%d/%s" $gatewayNamespace $gatewayName ($listener.port | int) $host) -}}
      {{- if $seen -}}
        {{- fail (printf "Route - Route [%s] and [listenerSet.%s] use hostname [%s] on the same gateway and port. Listeners conflict on a gateway and the oldest one wins. Attach the route with [listenerSet] instead of [tls]" $seen.route $name $host) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}

  {{- dict "listenerSets" $listenerSets "certificates" $certificates "routeParents" $routeParents | toYaml -}}
{{- end -}}

{{/* A secret per hostname, so routes that share a hostname reuse the certificate */}}
{{- define "tc.v1.common.lib.route.secretName" -}}
  {{- printf "%s-tls-%s" .chartName (.host | replace "*" "wildcard" | replace "." "-") -}}
{{- end -}}
